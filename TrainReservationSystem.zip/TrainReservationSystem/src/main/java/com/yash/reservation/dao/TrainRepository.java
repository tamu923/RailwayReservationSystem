package com.yash.reservation.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.yash.reservation.entity.Train;
import com.yash.reservation.model.TrainDetailsModel;

@Repository
public interface TrainRepository extends CrudRepository<Train, Long> {
	

}
