package com.yash.reservation.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.reservation.entity.TrainSchedule;
import com.yash.reservation.model.ResponseModel;
import com.yash.reservation.model.TicketReservationModel;
import com.yash.reservation.model.TrainDetailsModel;


@Service
public interface TrainDetailsService {

	ResponseModel getTrainDetails(TicketReservationModel ticketReservationModel);
	


	ResponseModel ticketBooking(TrainDetailsModel model);



	ArrayList<TicketReservationModel> getTrainSearchDetails();
	
	List<TicketReservationModel> listOfTrains(String fromAddress,String toAddress);
	

}
