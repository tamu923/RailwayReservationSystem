package com.yash.reservation.controllerTest;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.reservation.controller.RegistrationController;
import com.yash.reservation.dao.ReservationDao;
import com.yash.reservation.dao.UserRepository;
import com.yash.reservation.model.UserModel;
import com.yash.reservation.serviceImpl.RegistrationServiceImpl;

@WebMvcTest(RegistrationController.class)
public class RegistrationControllerTest {

	@Autowired
	MockMvc mockMvc;
	@MockBean
	ReservationDao custrepo;

	@MockBean
	EntityManager em;

	@MockBean
	UserRepository ur;
	@MockBean
	RegistrationServiceImpl regi;

	@Test
	public void userRegistrationTest() throws Exception {

		UserModel user = new UserModel();
		user.setUserName("shubham");
		user.setPassword("123");
		user.setEmail("s@gmail.com");
		user.setFirstName("Shubham");
		user.setGender("Male");
		user.setId(1);
		user.setLastName("jamkar");
		user.setMobileNumber(9999999999l);
	

		ObjectMapper mapper = new ObjectMapper();
		this.mockMvc
				.perform(post("/userRegistration").contentType(MediaType.APPLICATION_JSON)
						.accept(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(user)))

				.andExpect(status().isOk());

	}

	@Test
	public void getAllDataTest() throws Exception {
		List<UserModel> empList = Arrays.asList(new UserModel(102L, "e1", "gmail", "pune","sdd","sdd","dss","dsd"),
				new UserModel(101, "e1", "gmail", "pune","sdd","sdd","dss","dsd"));

		mockMvc.perform(get("/getAllUserData"))

				.andExpect(status().isOk());


	}

}
